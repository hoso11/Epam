#!/bin/bash
# delete file with name accounts_new.csv
mv ./accounts_new.csv ./accounts_new.csv.bkp
touch ./accounts_new.csv
accounts="./accounts.csv"
echo "id,locetion_id,name,title,email,department" >> ./accounts_new.csv
# read file 
while IFS="," read -r id locetion_id name title  email department;
do
        title1=$(echo $email | grep "@")
        #echo $title
        if [[ -z "$title1" ]] && [[ -n $email ]];
        then
                title=$title","$email
        fi
        # find name
        name11=$(echo $name | cut -d " " -f 1)
        # make name lowercase
        name1=${name11,,}
        # find surname
        surname1=$(echo $name | cut -d " " -f 2)
        # make surname lowercase
        surname=${surname1,,}
        name_surname="${name1^} ${surname^}"
        # make imales
        email11=$(echo $name | cut -c 1)
        email1=${email11,,}
        email=$(echo $email1$surname"@abc.com")
        email_changed=$(cat ./accounts.csv | grep -iF  "$name" | wc -l)
        # conect locetion_id with email
        if [[ $email_changed -eq "1" ]];
        then
                email=$email
        else
                email=$(echo $email1$surname$locetion_id"@abc.com")
        fi
        echo $id","$locetion_id","$name_surname","$title","$email","$department >> ./accounts_new.csv
done < $1
# delete last and second line
sed -i '$ d' ./accounts_new.csv
sed -i '2d' ./accounts_new.csv

