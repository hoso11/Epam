param($filepath) #get param for script

#get info from original file
$all_info = Import-Csv -Path  ./$filepath
#echo ./$filepath"

$dir_path = Split-Path ./$filepath

#colums row for create new file
$template = (Get-Content ./$filepath)[0]
#$template

#create new file
Out-File -FilePath "$dir_path\accounts_new.csv" -InputObject($template)


#loop for new faile data
foreach($user in $all_info) {


$id = $user.id
$location_id = $user.location_id
$fname = ($user.name).split(' ')[0]
$lname = ($user.name).split(' ')[1]
$fname = ($fname.ToUpper()[0]) + (($fname.ToLower()[1..($fname.Length - 1)]) -join '')
$lname = $lname.ToUpper()[0] + (($lname.ToLower()[1..($lname.Length - 1)]) -join '')
$title = $user.title
if($title -like "*,*") {$title = '"' + $title + '"'}
$email = $user.email
$department = $user.department


$email = $fname.ToLower()[0] + $lname.ToLower() + '@abc.com'
  



$changed_info = $id + ',' + $location_id + ',' + $fname + ' ' + $lname + ',' + $title + ',' + $email + ',' + $department

Out-File -FilePath "$dir_path\accounts_new.csv" -InputObject($changed_info) -Append


}
# conect locetion_id with email
$all_info2 = Import-csv -Path "$dir_path\accounts_new.csv"


$all_content = Get-Content "$dir_path\accounts_new.csv"
foreach ($user1 in $all_info2) {

$email_dub = ($all_content | where {$_.contains((($user1.email) -Split '@' )[0])}).count

 if($email_dub -gt 1) {
 
$uniq_row = $all_content | where {$_.contains($user1.email)} | where {$_.contains($user1.id)} | where {$_.contains($user1.name)}
$replace_email = (($user1.email).Split('@'))[0] + $user1.location_id + '@' + (($user1.email).Split('@'))[1]
$uniq_row2 = $uniq_row -replace $user1.email, $replace_email
$all_content  = $all_content -replace $uniq_row , $uniq_row2


 }

}

Out-File -FilePath "$dir_path\accounts_new.csv" -InputObject($all_content)
