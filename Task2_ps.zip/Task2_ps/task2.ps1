param($filepath) #get param for script
#get info from original file
$all_info = Import-Csv -Path  ./$filepath
#echo ./$filepath"

$dir_path = Split-Path ./$filepath

#colums row for create new file
$template = (Get-Content ./$filepath)[0]
#$template

#create new file
Out-File -FilePath "$dir_path\accounts_new.csv" -InputObject($template)


#loop for new faile data
foreach($user in $all_info) {


$id = $user.id
$location_id = $user.location_id
$fname = ($user.name).split(' ')[0]
$lname = ($user.name).split(' ')[1]
$fname = ($fname.ToUpper()[0]) + (($fname.ToLower()[1..($fname.Length - 1)]) -join '')
$lname = $lname.ToUpper()[0] + (($lname.ToLower()[1..($lname.Length - 1)]) -join '')
$title = $user.title
if($title -like "*,*") {$title = '"' + $title + '"'}
$email = $user.email
$department = $user.department


$check_dublicate = $all_info | where {($user.name).ToLower() -like ($_.name).ToLower() }

if($check_dublicate.count -gt 1) {

$email = $fname.ToLower()[0] + $lname.ToLower() + $location_id + '@abc.com'
 
  }
else {
  $email = $fname.ToLower()[0] + $lname.ToLower() + '@abc.com'
  
  }


$changed_info = $id + ',' + $location_id + ',' + $fname + ' ' + $lname + ',' + $title + ',' + $email + ',' + $department

Out-File -FilePath "$dir_path\accounts_new.csv" -InputObject($changed_info) -Append


}
