param($ip_address_1 , $ip_address_2 , $network_mask )
# regex for valid ip addres
$valid = '^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'

# cheek validatione ip1
#$ip_address_1 = read-host -Prompt "Please enter a ip_address_1"
if( $ip_address_1 -notmatch $valid ) #-or ($ip_address_1 -match "255.255.255.255") -or ($ip_address_1 -match "0.0.0.0") )
{
    Write-Output "is not an IP address1"
    Break
}

# binar value ip1
$ip_address_1_bin = -join ($ip_address_1.Split('.') | ForEach-Object {[System.Convert]::ToString($_,2).PadLeft(8,'0')})


#$ip_address_2 = read-host -Prompt "Please enter a ip_address_2"
# cheek validatione ip2
if( $ip_address_2 -notmatch $valid ) #-or ($ip_address_2 -match "255.255.255.255") -or ($ip_address_2 -match "0.0.0.0") )
{
    Write-Output "is not an IP address2"
    Break
}

# binar value ip2
$ip_address_2_bin = -join ($ip_address_2.Split('.') | ForEach-Object {[System.Convert]::ToString($_,2).PadLeft(8,'0')})


# regex for valid network_mask
$valid_net = "^(254|252|248|240|224|192|128).0.0.0$|^255.(254|252|248|240|224|192|128|0).0.0$|^255.255.(254|252|248|240|224|192|128|0).0$|^255.255.255.(255|254|252|248|240|224|192|128|0)$|0.0.0.0"
$valid_net_1 = "^[0-9]$|^([1-2])[0-9]$|^([3])[0-2]$"
# = read-host -Prompt "Please enter a network_mask"

# cheek validatione network mask
if( $network_mask -notmatch $valid_net -and $network_mask -notmatch $valid_net_1)
{
    Write-Output "is not an network mask"
    Break
} 

# count unchangeable part of network mask
if ( $network_mask.Length -gt 3 )
{
    $network_mask_bin = -join ($network_mask.Split('.') | ForEach-Object {[System.Convert]::ToString($_,2).PadLeft(8,'0')})
    $network_mask_bin_1 = $network_mask_bin.split("0")
    $measureobject = $network_mask_bin_1 | Measure-Object -Character
    $count = $measureobject.Characters
}
else 
{
    $count = $network_mask
}

# count unchangeable part of binary ip addres
if ( $network_mask -eq "0" -or $network_mask -eq "0.0.0.0" )
{
    $x = 0
    $y = 0
}
else
{
    $ip_address_1_bin_1 = $ip_address_1_bin[0..($count - 1)]
    $x = -join $ip_address_1_bin_1

    $ip_address_2_bin_1 = $ip_address_2_bin[0..($count - 1)]
    $y = -join $ip_address_2_bin_1
}


if( $x -eq $y )
{
    Write-Output "yes"
}else {
    Write-Output "no"
}
