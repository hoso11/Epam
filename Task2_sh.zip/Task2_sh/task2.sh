#!/bin/bash

# vars
# var echo "Asserts_Samples"
testName_value=$(cat $1 | head -1 | cut -d " " -f 2-3)
# var echo "test"
test_value=$(cat $1 | head -1 | cut -d " " -f 6)
# var number of lines
count_lines=$(cat $1 | wc -l)
# var number of lines using "for loop"
count_lines1=$((count_lines - 4))
# var number success tests
success_value=$(cat $1 | tail -1 | cut -d " " -f 1)
# var number failed tests
failed_value=$(($count_lines1 - $success_value))
# var taking rating
rating_value=$(cat $1 | tail -1 | cut -d "%" -f 1 | awk '{print $NF}')
# var taking duratione
duration_value=$(cat $1 | tail -1  | awk '{print $NF}')


# main for making output.json file

# touch output.json file and write 
echo "{" > output.json
echo ' "testName":''"'$testName_value'",'  >> output.json
echo ' "'$test_value'":[' >> output.json
# with loop take from output.txt some arguments and use it on output.json
for ((i = 0 ; i < $count_lines1 ; i++)); do
        j=$((-3 - $i))
        arg_1=$(cat $1 | head $j | tail -1 | cut -d " " -f 1)
        arg_3=$(cat $1 | head $j | tail -1 | cut -d ")" -f 2 | cut -d " " -f 2)
        # find "ok" and "not ok" lines
        if [[ "$arg_1" == "not" ]]; then
                arg_1=$(cat $1 | head $j | tail -1 | cut -d ")" -f 1 | cut -d " " -f 6-)
                arg_2="false"
        else
                arg_1=$(cat $1 | head $j | tail -1 | cut -d ")" -f 1 | cut -d " " -f 5-)
                arg_2="true"
        fi
  echo "   {" >> output.json
  echo '    "name":''"'$arg_1')",' >> output.json
  echo '    "status":'$arg_2',' >> output.json
  echo '    "duration":''"'$arg_3'"' >> output.json
  echo "   }," >> output.json
done
# delet last line
sed -i '$ d' ./output.json
# 
echo "   }" >> output.json
echo "]," >> output.json
echo ' "summary":{' >> output.json
echo ' "success":'$success_value"," >> output.json
echo ' "failed":'$failed_value"," >> output.json
echo ' "rating":'$rating_value"," >> output.json
echo ' "duration":''"'$duration_value'"' >> output.json
echo " }" >> output.json
echo "}" >> output.json
